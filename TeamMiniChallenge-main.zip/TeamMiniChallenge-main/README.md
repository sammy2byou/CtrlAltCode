# TeamMiniChallenge 
Team mini challenge for WinHacks 2021

Find more info: http://discord.winhacks.ca #mini-challenge-info

<img src="https://user-images.githubusercontent.com/46850194/111094692-329d3080-8512-11eb-978d-bad694ed06d3.png" width="100">

